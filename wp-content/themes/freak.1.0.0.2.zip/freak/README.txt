Freak WordPress Theme
GNU GPL v3
Copyrights 2015. Rohit Tripathi.
http://rohitink.com/


Freak
=========

Freak is a Beautiful WordPress Theme with a Stunning Parallax Header Background. Many other features include a Unique Posts Page, Multile Blog Layouts, Customizable Sidebar Width, A Fully Featured Responsive Slider, Multiple Menu Bars, A Static Navigation Bar, Stylish Social Icons, Unique Search Options and Much More. This theme has been throughly tested with all Modern Mobile Platforms including Android, iPhone and Windows Phone and it works Flawlessly. Freak is one of the Best Responsive Themes out there. THEME DEMO -> http://demo.inkhive.com/freak/


Getting Started
---------------

How to Install the Theme?

1. Go to WP Admin > Appearance > Themes > Add New.
2. Search for "Freak".
3. Click on Install and Activate.

Alternatively,

1. Go to WP Admin > Appearance > Themes > Add New > Upload.
2. Upload the freak.zip file, in which you found this README.txt
3. Click on Install and Activate.

Setting it Up
-------------

This theme is built using Customizer. So to Configure theme settings like Featured Posts, Sliders, Social Icons, etc from 
	
	Dashboard > Appearance > Customizer	
	
	

Report Bugs / Theme Support
---------------------------

Freak is a Brand new theme, and could contain some hidden bugs. So, if you find any please report them at the following URL:

http://rohitink.com/contact-me/


External Resources / Licenses
-----------------------------

This theme is 100% GPL. And any external resources used and bundled with the theme are also Fully Compatible with the GPL.

1. Font Awesome
	- Code under MIT License
	- Font under SIL OFL 1.1 
	- http://fortawesome.github.io/Font-Awesome/
	
2. Bootstrap
	- MIT License
	- http://getbootstrap.com
	
3. Hover.css
	- MIT License
	- http://ianlunn.github.io/Hover/
	
4. Slicknav
	- MIT License
	- https://github.com/ComputerWolf/SlickNav
	
5. Stellar.js
	- MIT License
	- https://github.com/markdalgleish/stellar.js
						
6. Nivo Slider
	- MIT LIcense
	- https://github.com/gilbitron/Nivo-Slider	
	
7. _S/Underscores Framework
	- GPL v2
	- http://underscores.me

8. Modernizer 			
	- MIT and BSD
	- http://modernizr.com
	
9. Responsive Menu
	- https://github.com/mattkersley/Responsive-Menu
	- MIT license

10. jQuery Visible
	- MIT License
	- https://github.com/customd/jquery-visible/

11. Flex Images
	- MIT License
	- https://github.com/Pixabay/jQuery-flexImages
	
12. Slideout.js
	- https://github.com/Mango/slideout
	- MIT License
				
	

All Other Resources, apart from the ones mentioned above have been created by me fall under GPL v3 license of the theme.	

Screenshot Image Credits
------------------------

All the Images used in the Screenshot are Public Domain.
https://creativecommons.org/publicdomain/zero/1.0/

List of Images
	- http://pixabay.com/en/city-night-lights-streets-roads-690332/ (Default Header Image)
	- http://pixabay.com/en/woodland-road-falling-leaf-natural-656969/
	

		